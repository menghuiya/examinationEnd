/*
 * @Author: menghui
 * @Date: 2020-05-12 14:59:18
 * @Last Modified by: menghui
 * @Last Modified time: 2020-06-25 21:15:46
 */
/**created by 梦回 */
let mongoose = require("mongoose");
//用户的表结构
const UserSchema = new mongoose.Schema(
  {
    openid: String,
    name: String,
    create_time: Number,
  },
  { versionKey: false }
);

module.exports = mongoose.model("User", UserSchema);
