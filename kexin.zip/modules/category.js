let mongoose = require("mongoose");
// 分类表结构
const CategorySchema = new mongoose.Schema(
  {
    name: String, //分类名
    type: String, //分类值 以后有用吧 别名
    parentId: mongoose.Schema.Types.ObjectId, //父类id关联字段 以后如果二级分类
    isOpen: {
      //该分类是否可用
      type: Boolean,
      default: true,
    },
    createTime: {
      //创建时间
      type: Date,
    },
  },
  { versionKey: false }
);

module.exports = mongoose.model("Category", CategorySchema);
