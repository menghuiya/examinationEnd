let Admin = require("../modules/admin");

//增加后台账号
exports.add = async (req, res) => {
  console.log(req.body);
  const result = await Admin({
    username: req.body.username,
    password: req.body.password,
    create_time: Date.now(),
  }).save();
  console.log(result);
};

//登录后台账号
exports.login = (req, res) => {
  Admin.findOne({
    username: req.body.username,
  }).then((result) => {
    if (!result) {
      res.json({
        status: 0,
        msg: "用户不存在",
      });
    } else if (result.password === req.body.password) {
      req.session.user = {
        _id: result._id,
        username: result.username,
      };
      res.json({
        status: 1,
        data: {
          _id: result._id,
          username: result.username,
        },
      });
    } else {
      res.json({
        status: 0,
        msg: "密码错误",
      });
    }
  });
};
