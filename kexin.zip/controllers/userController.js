let User = require("../modules/user");

//用户列表
exports.list = async (req, res) => {
  let page = Number(req.query.page || 1); //注意验证 是否为数字
  let limit = Number(req.query.limit || 5); //注意验证 是否为数字 //限制条数
  User.count().then(function (count) {
    //计算总页数
    let pages = Math.ceil(count / limit);
    //取值不能超过pages
    page = Math.min(page, pages);
    //取值不能小于1
    page = Math.max(page, 1);
    //限定上一页下一页取值
    let skip = (page - 1) * limit;
    User.find()
      .limit(limit)
      .skip(skip)
      .sort({ _id: -1 })
      .then(function (users) {
        let mockData = {
          status: 1,
          msg: "ok",
          data: users,
          dataCount: count,
        };
        // console.log(mockData);
        res.json(mockData);
      });
  });
};
