const express = require("express");
const router = express.Router();

// router.post("/login", inviteController.login);
// router.get("/codeimg", inviteController.codeimg);
// router.get("/subcode", inviteController.subcode);

module.exports = router;
